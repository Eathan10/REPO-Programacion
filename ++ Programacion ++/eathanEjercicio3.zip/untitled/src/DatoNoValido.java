import javax.swing.*;

public class DatoNoValido extends Exception{
    public DatoNoValido(String mensaje){
        super(mensaje);
    }
}
