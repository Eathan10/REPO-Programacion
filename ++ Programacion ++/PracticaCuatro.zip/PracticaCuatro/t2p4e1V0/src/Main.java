import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*
        Escribe un programa que pida al usuario que introduzca dos números
        e intente dividir el primero entre el segundo. También hay que calcular
        la raíz cuadrada de los mismos.
         */
        try
        {
            int n1 = solicitarNumero();
            int n2 = solicitarNumero();
            dividir(n1,n2);
            raizCuadrada(n1);
            raizCuadrada(n2);
        }
        catch(Exception e)
        {
            System.out.println("Problemas: " + e.getMessage());
        }
    }

    public static int solicitarNumero()
    {
        boolean error = true;
        int numero=0;
        do
        {
            try
            {
                Scanner sc = new Scanner(System.in);
                System.out.println("Teclea un número");
                numero = sc.nextInt();
                error = false;
            }
            catch(InputMismatchException e)
            {
                System.out.println("Problemas: No me has tecleado un número de tipo int" );
            }
            catch(Exception e)
            {
                System.out.println("Problemas: " + e.getClass());
            }
        }
        while(error); // error == true
        return numero;

    }

    public static void dividir(int n1,int n2)
    {
        try
        {
            int cociente = n1 / n2;
            System.out.println("El resultado de la división es: " + cociente);
        }
        catch(ArithmeticException e)
        {
            System.out.println("Problemas: " + e.getMessage());
        }
        catch(Exception e)
        {
            System.out.println("Problemas " + e.getClass());
        }
    }

    public static void raizCuadrada(int numero)
    {
        try
        {
            // Si el número es negativo, java no genera una excepción. Devuelve NaN
            Double resultado = Math.sqrt(numero);
            if (resultado.isNaN())
                System.out.println("No se puede calcular la raiz de un número negativo");
            else
                System.out.println("La raíz cuadrada de " + numero + " es " + resultado);
        }
        catch(Exception e)
        {
            System.out.println("Problemas: " + e.getMessage());
        }
    }
}