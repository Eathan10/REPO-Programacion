package Excepciones;

public class DatoDeEntradaNoValido extends Exception{
}
