import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*
        Escribe un programa que pida al usuario que introduzca dos números
        e intente dividir el primero entre el segundo. También hay que calcular
        la raíz cuadrada de los mismos.
         */
        try {
            int n1 = solicitarNumero();
            int n2 = solicitarNumero();
            dividir(n1,n2);
            raizCuadrada(n1);
            raizCuadrada(n2);
        }
        catch(Exception e)
        {
            System.out.println("Problemas: " + e.getMessage());
        }
    }

    public static int solicitarNumero() throws Exception
    {
        boolean error = true;
        int numero=0;
        do
        {
            try
            {
                Scanner sc = new Scanner(System.in);
                System.out.println("Teclea un número");
                numero = sc.nextInt();
                error = false;
            }
            catch(InputMismatchException e)
            {
                System.out.println("Problemas: No me has tecleado un número de tipo int" );
            }
        }
        while(error);
        return numero;

    }

    public static void dividir(int n1,int n2) throws Exception
    {
        try
        {
            int cociente = n1 / n2;
            int resto = n1 % n2;
            if (resto != 0)
                throw new DivisionNoEntera();
            System.out.println("El resultado de la división es: " + cociente);
        }
        catch(ArithmeticException e)
        {
            System.out.println("Problemas: " + e.getMessage());
        }
        catch(DivisionNoEntera e)
        {
            System.out.println("Problemas: Los números no son divisibles");
        }
    }

    public static void raizCuadrada(int numero) throws Exception
    {
        try
        {
            // Si el número es negativo, java no genera una excepción. Devuelve NaN
            /*if (numero < 0)
                throw new NumeroNegativoException();
            double resultado = Math.sqrt(numero);*/

            Double resultado = Math.sqrt(numero);
            if (resultado.isNaN())
                throw new NumeroNegativoException();
            System.out.println("La raíz cuadrada de " + numero + " es " + resultado);
        }
        catch(NumeroNegativoException e)
        {
            System.out.println("Problemas: No se puede calcular la raíz cuadrada de un número negativo");
        }
    }
}