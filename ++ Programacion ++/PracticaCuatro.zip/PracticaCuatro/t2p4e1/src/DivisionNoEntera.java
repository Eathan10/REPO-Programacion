public class DivisionNoEntera extends Exception{
}
