public class Prueba extends Exception{
}
